package com.frank.living.listener;

import tv.danmaku.ijk.media.player.IjkMediaPlayer;

/**
 *
 * Created by frank on 2019/1/4.
 */

public interface IjkPlayerListener {

    void onIjkPlayer(IjkMediaPlayer ijkMediaPlayer);

}
