package com.frank.living.constant;

public class Constants {

    //broadcast of add client
    public final static String ACTION_CLIENT_ADD = "action.client.ADD";
    //broadcast of remove client
    public final static String ACTION_CLIENT_REMOVE = "action.client.REMOVE";

}
