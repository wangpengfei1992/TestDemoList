package com.frank.ffmpeg.listener

/**
 * listener of RecyclerView item clicking
 * Created by frank on 2018/6/6.
 */

interface OnItemClickListener {

    fun onItemClick(position: Int)
}
