package com.frank.ffmpeg.format

/**
 * layout of video
 * Created by frank on 2018/6/18.
 */

object VideoLayout {

    //horizontal join
    const val LAYOUT_HORIZONTAL = 1
    //vertical join
    const val LAYOUT_VERTICAL = 2

}
