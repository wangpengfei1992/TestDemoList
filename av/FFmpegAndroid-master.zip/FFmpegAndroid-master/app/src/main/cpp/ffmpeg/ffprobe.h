//
// Created by frank on 2020-01-06.
//

#ifndef FFMPEGANDROID_FFPROBE_H
#define FFMPEGANDROID_FFPROBE_H

char* ffprobe_run(int argc, char **argv);

void frank_printf_json(char *fmt, ...);

#endif //FFMPEGANDROID_FFPROBE_H
