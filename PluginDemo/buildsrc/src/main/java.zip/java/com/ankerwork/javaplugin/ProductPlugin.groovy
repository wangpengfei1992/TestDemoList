package com.ankerwork.javaplugin

import org.gradle.api.Action
import org.gradle.api.Plugin
import org.gradle.api.Project

public class ProductPlugin implements Plugin<Project> {

    @Override
    public void apply(Project project) {
        System.out.println("=============java===========");
       /* ProductTask productTask = project.getTasks().create("productTask",ProductTask.class,new Action<ProductTask>() {
            @Override
            void execute(ProductTask t) {
                System.out.println(" execute ProductTask");
            }
        })*/
    }
}