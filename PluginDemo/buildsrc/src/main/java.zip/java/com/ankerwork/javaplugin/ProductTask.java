package com.ankerwork.javaplugin;

import org.gradle.api.DefaultTask;
import org.gradle.api.tasks.TaskAction;

/**
 * Author: feipeng.wang
 * Time:   2022/1/13
 * Description : This is description.
 */
public class ProductTask extends DefaultTask {
    // TaskAction注解的方法，会在gradle build执行阶段执行
    @TaskAction
    public void doAction() {
        // 将内容写入文件
        com.ankerwork.javaplugin.Param param = (Param) getProject().getExtensions().getByName("productPlugin");
        System.out.println("doAction task"+param.getPdroductcode());
    }
}
