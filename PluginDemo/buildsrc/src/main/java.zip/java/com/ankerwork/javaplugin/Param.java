package com.ankerwork.javaplugin;

/**
 * Author: feipeng.wang
 * Time:   2022/1/13
 * Description : 配置信息.
 */
public class Param {
    private String pdroductcode;

    public String getPdroductcode() {
        return pdroductcode;
    }

    public void setPdroductcode(String pdroductcode) {
        this.pdroductcode = pdroductcode;
    }
}
