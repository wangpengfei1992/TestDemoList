package com.ankerwork.groovyplugin

import org.gradle.api.Plugin
import org.gradle.api.Project

public class ProductGroovyPlugin implements Plugin<Project> {

    @Override
    void apply(Project target) {
        println("------------groovy------------")
        //do something
        def extension = target.extensions.create("productPlugin", com.ankerwork.javaplugin.Param)
        target.task('pluginTest') {
            doLast {
                println("新内容是:${extension.pdroductcode}")
            }
        }
    }
}