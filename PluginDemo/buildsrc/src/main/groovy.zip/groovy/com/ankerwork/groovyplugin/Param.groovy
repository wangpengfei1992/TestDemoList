package com.ankerwork.groovyplugin
class Param {
    String pdroductcode

}